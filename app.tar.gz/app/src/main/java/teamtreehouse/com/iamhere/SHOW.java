package teamtreehouse.com.iamhere;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;

import android.widget.LinearLayout;
import android.widget.TextView;
public class SHOW extends ActionBarActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show);
        Intent intent3 = getIntent();
        String message = intent3.getStringExtra(MapsActivity.EXTRA_MESSAGE);
        String message1 = intent3.getStringExtra(MapsActivity.EXTRA_MESSAGE1);
        TextView textView1 = new TextView(this);
        TextView textView2 = new TextView(this);
        TextView textView3 = new TextView(this);
        textView1.setTextSize(20);
        textView1.setText(message);
        LinearLayout layout = (LinearLayout) findViewById(R.id.content);
        layout.addView(textView1);
        String message2="                            ";
        textView3.setTextSize(20);
        textView3.setText(message2);
        layout.addView(textView3);
        textView2.setTextSize(20);
        textView2.setText(message1);
        layout.addView(textView2);
    }
}